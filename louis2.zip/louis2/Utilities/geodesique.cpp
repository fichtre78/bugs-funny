#include "geodesique.h"

// Arrondi
IntPoint2 arrondi(const Vect2 p) {
    return IntPoint2((int)(p[0]+0.5f), (int)(p[1]+0.5f));
}

// Ajoute poids gaussiens a W.
void ajouteGaussienne(Image<float>& W, float xc, float yc, float r) {
    for(int i=0; i<W.height(); i++)
        for(int j=0; j<W.width(); j++)
            W(j,i) += 500*exp( -((j-xc)*(j-xc)+(i-yc)*(i-yc)) / (r*r) );
}

void ajouteBloc(Image<float>& W, float xc, float yc, int intensite, int cote_case)
{
    for (int i=0; i<cote_case; i++)
    {
        for (int j=0; j<cote_case; j++)
        {
            W(xc+i,yc+j)+=intensite;
        }
    }
}

void initPoids(Image<float>& W, FMatrix<Case, g_w, g_h> lvl1, const int cote_case)
{
    int diag = sqrt(250);

    for (int i=0; i<lvl1.nrow(); i++)
    {
        for (int j=0; j<lvl1.ncol(); j++)
        {
            if(lvl1(i,j).get_etat()==1)
            {
                ajouteGaussienne(W,(i+0.5)*cote_case,(j+0.5)*cote_case,diag);
                ajouteBloc(W,i*cote_case,j*cote_case,500,cote_case);
            }

            if(lvl1(i,j).get_etat()==2)
            {
                ajouteGaussienne(W,(i+0.5)*cote_case,(j+0.5)*cote_case,diag);
                ajouteBloc(W,i*cote_case,j*cote_case,500,cote_case);
            }
        }
    }
}

// Calcule la geodesique de p1 a p2.
vector<Vect2> geodesique(const Image<float>& D,
                               Vect2 p1, Vect2 p2) {
    vector<Vect2> v;
    v.push_back(p2);
    while(norm(p2-p1)>1.0f) {
        Vect2 grad = gradient(D, arrondi(p2));
        grad /= norm(grad);
        p2 = p2 - TAU*grad;
        v.push_back(p2);
    }
    v.push_back(p1);
    return v;
}

