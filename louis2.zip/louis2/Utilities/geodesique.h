#pragma once

#include "fastMarching.h"
#include <iostream>
#include "../Global/vect2.h"
#include "../World/case.h"

const float TAU=0.01f; // Increment dans la direction opposee au gradient

// Arrondi
IntPoint2 arrondi(const Vect2 p);

// Ajoute poids gaussiens a W.
void ajouteGaussienne(Image<float>& W, float xc, float yc, float r);

void initPoids(Image<float>& W, FMatrix<Case, g_w, g_h> lvl1, const int cote_case);

// Calcule la geodesique de p1 a p2.
vector<Vect2> geodesique(const Image<float>& D,
                               Vect2 p1, Vect2 p2);
