#include "vect2.h"

void dessine_image(Vect2 v, Imagine::NativeBitmap nb, int nb_w, int nb_h, int zoom)
{
    putNativeBitmap(v.x()*zoom+(zoom-nb_w)/2,v.y()*zoom+(zoom-nb_h)/2,nb);
}

void efface_image(Vect2 v, int nb_w, int nb_h, int zoom)
{
    fillRect(v.x()*zoom+(zoom-nb_w)/2,v.y()*zoom+(zoom-nb_h)/2,nb_w,nb_h,Imagine::WHITE);
}
