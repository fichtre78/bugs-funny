#pragma once

//Permet de définir une seule fois le typedef
#include <Imagine/Common.h>
#include <Imagine/Graphics.h>

typedef Imagine::FVector<float,2> Vect2;

const int g_hauteur = 500;
const int g_nb_case_colonne = 10;
const int g_dist = 2;
const int g_largeur = g_dist*g_hauteur;

const int g_w = g_dist*g_nb_case_colonne;
const int g_h = g_nb_case_colonne;
const int g_cote_case = g_hauteur/g_nb_case_colonne;

void dessine_image(Vect2 v, Imagine::NativeBitmap nb, int nb_w, int nb_h, int zoom);
void efface_image(Vect2 v, int nb_w, int nb_h, int zoom);

