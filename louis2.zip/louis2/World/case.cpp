#include "case.h"

Color CouleurCase(byte R, byte G, byte B)
{
    Color C = Color(R,G,B);
    return(C);
}

Case::Case()
{
    m_etat=0;
}

int Case::get_etat()
{
    return m_etat;
}

void Case::set_etat(int etat)
{
    m_etat = etat;
}

