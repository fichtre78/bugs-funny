// mettre les memes includes que dans le .h ?
#include "ennemi.h"








