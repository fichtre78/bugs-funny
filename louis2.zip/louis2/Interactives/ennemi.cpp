// mettre les memes includes que dans le .h ?
#include "ennemi.h"


void Ennemi::avancer(Vect2 point_suiv)
{
    m_pos = point_suiv;
}

void Ennemi::afficher(int zoom)
{
    putNativeBitmap(m_pos.x()*zoom,m_pos.y()*zoom,m_skin);
}

void Ennemi::effacer(int zoom, int nb_w, int nb_h)
{
    fillRect(m_pos.x()*zoom,m_pos.y()*zoom,nb_w,nb_h,Imagine::WHITE);
}


void Ennemi::setSkin(Imagine::NativeBitmap skin, std::string adress)
{
    int nb_w, nb_h;
    byte* rgb;
    loadColorImage(srcPath("m_adress"),rgb,nb_w,nb_h);
    m_skin=skin;
    m_adress=adress;
}
