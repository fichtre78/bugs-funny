#pragma once

#include "../Global/vect2.h"

#include <Imagine/Graphics.h>
using namespace Imagine;

class Ennemi
{
    //Attributs
    Vect2 m_pos;
    int m_hp;
    double m_speed;
    double m_size;
    bool m_reach_end;
    bool m_dead;
    Imagine::NativeBitmap m_skin;
    std::string m_adress;

public:
    //Méthodes
    void recevoir_degat(int nb_degat);
    void avancer(Vect2 point_suiv);
    void afficher(int zoom);
    void effacer(int zoom, int nb_w, int nb_h);
    bool isDead();

    void setSkin(Imagine::NativeBitmap skin, std::string adress);
};

class Punaise : public Ennemi
{

};

class Gaspard : public Ennemi
{

};

class Ibrahim : public Ennemi
{

};
