// Imagine++ project
// Project:  Bugs Funny

#include <Imagine/Graphics.h>
using namespace Imagine;

#include <vector>
using namespace std;

#include "World/case.h"
#include "Utilities/geodesique.h"
#include "Interactives/ennemi.h"

/* LA GRILLE */

//Variables et paramètres
int m_params_g[5];

//Fonctions
void initParamsG(int hauteur, int nb_case_colonne, int dist, int params[5]) //avec dist le rapport largeur/hauteur (la distortion)
{
    params[0] = dist * hauteur; //Largeur
    params[1] = hauteur; //Hauteur
    params[2] = nb_case_colonne*dist; //Nombre de cases par ligne (en largeur) (Nombre de colonnes)
    params[3] = nb_case_colonne; //Nombre de case par colonne (en hauteur) (Nombre de lignes)
    params[4] = hauteur/nb_case_colonne; //Le coté d'une case
}

Color Couleur(byte R, byte G, byte B)
{
    Color C = Color(R,G,B);
    return(C);
}

void dessineCase(int i, int j, int params_g[5], int etat)
{
    int size = params_g[4];
    if(etat==1)
        fillRect(i*size, j*size, size, size, BLACK);
    if(etat==2)
        fillRect(i*size, j*size, size, size, Couleur(100,100,100));
}

/* LE NIVEAU */

//Variables et paramètres
const int nb_para = 1;
int m_params_lvl[nb_para] = {15}; //[nombre de cases que l'utilisateur peut placer]

FMatrix<Case, g_w, g_h>  m_lvl1; //Matrice qui sert à définir l'état de chaque case (occupée ou non par un mur, ...)
                               //ATTENTION : Les parametres de lamatrice (de taille), doivent etre rentrés a la main, et recalculé a chaque chgmt

//Fonctions

void dessinDepart(){}

void whichCase(int &x, int &y, int params_g[5])
{
    x = x/params_g[4];
    y = y/params_g[4];
}

void initGrille(int params_g[5], FMatrix<Case, g_w, g_h>  &lvl1) //Structure l'espace de jeu
{
    // trace des ligne verticales
    for (int i=0 ; i<params_g[2] ; i++)
    {
        drawLine(i*params_g[4],0,i*params_g[4],params_g[1], BLACK, 1);
    }

    // trace des lignes horizontales
    for (int j=0 ; j<params_g[3] ; j++)
    {
        drawLine(0,j*params_g[4],params_g[0],j*params_g[4],BLACK,1);
    }

    //Dessin du lit
    Color beige = Couleur(250, 243, 182);
    Color bleu_couv = Couleur(22, 114, 156);
    Color bleu_drap = Couleur(188, 212, 226);
    fillRect(0, 0, params_g[4]*2, 3*params_g[4], bleu_drap);
    fillRect(0, params_g[4], params_g[4]*2, 2*params_g[4], bleu_couv);
    fillRect(params_g[4]/5, params_g[4]/4, 8*params_g[4]/5, params_g[4]/3, beige);

    //Phase de remplissage avec les obstacles predefinis
    for(int i=0; i<lvl1.nrow(); i++)
    {
        for(int j=0; j<lvl1.ncol(); j++)
        {
            int etat = lvl1(i,j).get_etat()==1;
            if(etat)
                dessineCase(i, j, params_g, etat);
        }
    }
}

void effaceGrille(int params_g[5])
{
    // efface ligne verticales
    for (int i=0 ; i<params_g[2] ; i++)
    {
        drawLine(i*params_g[4],0,i*params_g[4],params_g[1], WHITE, 1);
    }

    // efface lignes horizontales
    for (int j=0 ; j<params_g[3] ; j++)
    {
        drawLine(0,j*params_g[4],params_g[0],j*params_g[4],WHITE,1);
    }
}

void choixObstacles(int params_lvl[nb_para], int params_g[5], FMatrix<Case, g_w, g_h>  &lvl1)
{
    int x=0;
    int y=0;
    //Phase ou l'utilisateur choisi
    for(int i=0; i<params_lvl[0]; i++)
    {
         getMouse(x,y);
         whichCase(x, y, params_g);
         lvl1(x,y).set_etat(2);
         dessineCase(x, y, params_g, 2);
    }
}


int main()
{
    initParamsG(g_hauteur, g_nb_case_colonne, g_dist, m_params_g);
    openWindow(m_params_g[0], m_params_g[1]);
    initGrille(m_params_g, m_lvl1);
    choixObstacles(m_params_lvl, m_params_g, m_lvl1);
    effaceGrille(m_params_g);

    // FastMArching

    Image<float> W(g_largeur,g_hauteur);
    W.fill(1.0f);

    initPoids(W,m_lvl1,g_cote_case);


    //affiche(W);

    Vect2 p1(g_largeur-0.5*g_cote_case,g_hauteur-0.5*g_cote_case);
    Vect2 p2(g_cote_case,1.5*g_cote_case);

    std::vector<PointDist> v;
    v.push_back( PointDist(p1[1],p1[0],0) );

    Image<float> D = fastMarching(W, v);
    vector<Vect2> chemin = geodesique(D, p1, p2);
    vector<Vect2> copie_chemin = chemin;

    Vect2 q=copie_chemin.back();
    copie_chemin.pop_back();
    while(! copie_chemin.empty()) {
        Vect2 p = copie_chemin.back();
        copie_chemin.pop_back();
        drawLine(arrondi(q), arrondi(p), RED, 2);
        q = p;
    }

    // AFFICHAGE VAGUE ENNEMI
    NativeBitmap nb_moto (20,14);
    byte* rgb;
    int nb_w,nb_h;
    loadColorImage(srcPath("bedbug.bmp"),rgb,nb_w,nb_h);
    nb_moto.setColorImage(0,0,rgb,nb_w,nb_h);
    delete[] rgb;

    Ennemi bug;
    bug.setSkin(nb_moto,"bedbug.bmp");
    while(! chemin.empty()) {
        Vect2 p = chemin.back();
        chemin.pop_back();
        bug.avancer(p);
        bug.afficher(1);
        bug.effacer(1,nb_w,nb_h);
    }

endGraphics();
return 0;
}
