#include "fastMarching.h"
#include <iostream>

typedef FVector<float,2> FloatPoint2;

const int w=512, h=512;
const float TAU=0.8f; // Increment dans la direction opposee au gradient

IntPoint2 arrondi(const FloatPoint2 p) {
    return IntPoint2((int)(p[0]+0.5f), (int)(p[1]+0.5f));
}

// Selection a la souris d'un cercle.
bool selectionCercle(int& xc, int& yc, float& r) {
    Color* cols; int w,h;
    captureWindow(cols, w, h);
    Image<Color> I(cols, w, h, true);
    Event e;
    do {
        getEvent(0, e);
        if(e.type==EVT_BUT_ON) {
            xc = e.pix[0];
            yc = e.pix[1];
            r = 0;
            if(e.button==3)
                return false;
        }
        if(e.type==EVT_MOTION) {
            float dx=xc-e.pix[0], dy=yc-e.pix[1];
            r = sqrt(dx*dx+dy*dy);
            display(I);
            drawCircle(xc, yc, (int)(r+0.5f), GREEN);
        }
    } while(e.type!=EVT_BUT_OFF || r<3.0f);
    return true;
}

// Ajoute poids gaussiens a W.
void ajouteGaussienne(Image<float>& W, float xc, float yc, float r) {
    for(int i=0; i<W.height(); i++)
        for(int j=0; j<W.width(); j++)
            W(j,i) += exp( -((j-xc)*(j-xc)+(i-yc)*(i-yc)) / (r*r) );
}

// Calcule la geodesique de p1 a p2.
vector<FloatPoint2> geodesique(const Image<float>& D,
                               FloatPoint2 p1, FloatPoint2 p2) {
    vector<FloatPoint2> v;
    v.push_back(p2);
    while(norm(p2-p1)>1.0f) {
        FloatPoint2 grad = gradient(D, arrondi(p2));
        grad /= norm(grad);
        p2 = p2 - TAU*grad;
        v.push_back(p2);
    }
    v.push_back(p1);
    return v;
}

int main() {
    openWindow(w,h);
    Image<float> W(w,h);
    W.fill(1.0f);

    cout << "Placez des cercles, clic droit pour terminer" << endl;
    int xc, yc; float r;
    while(selectionCercle(xc, yc, r)) {
        ajouteGaussienne(W, xc, yc, r);
        affiche(W);
    }
    cout << "Cliquez les points de depart et d'arrivee" << endl;
    IntPoint2 p1, p2;
    while(getMouse(p1)==1) {
        affiche(W);
        fillCircle(p1,2,GREEN);
        getMouse(p2); fillCircle(p2,2,WHITE);
        std::vector<PointDist> v;
        v.push_back( PointDist(p1[1],p1[0],0) );
        Image<float> D = fastMarching(W, v);

        vector<FloatPoint2> chemin = geodesique(D, p1, p2);
        FloatPoint2 q=chemin.back();
        chemin.pop_back();
        while(! chemin.empty()) {
            FloatPoint2 p = chemin.back();
            chemin.pop_back();
            drawLine(arrondi(q), arrondi(p), WHITE);
            q = p;
        }
    }

    endGraphics();
    return 0;
}
