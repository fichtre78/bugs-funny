#pragma once

#include "vect2.h"

#include <Imagine/Graphics.h>
using namespace Imagine;

Color CouleurCase(byte R, byte G, byte B);

class Case
{
    //Attributs
    int m_size;
    int m_etat; //1 : mur choisi par nous, 2 : mur choisi par l'utilisateur, 0 : vide
    Vect2 m_centre;

    //Méthodes
public :
    Case();
    int get_etat();
    void set_etat(int etat);
    void effaceCase(int coord[2]);
};
