#pragma once

//Permet de définir une seule fois le typedef
#include <Imagine/Common.h>
typedef Imagine::FVector<int,2> Vect2;
