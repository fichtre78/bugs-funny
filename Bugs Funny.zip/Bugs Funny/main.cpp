// Imagine++ project
// Project:  Bugs Funny

#include <Imagine/Graphics.h>
using namespace Imagine;

#include <vector>
using namespace std;

#include "case.h"

/* LA GRILLE */

//Variables et paramètres
int m_params_g[5];

//Fonctions
void initParamsG(int hauteur, int nb_case_colonne, int dist, int params[5]) //avec dist le rapport largeur/hauteur (la distortion)
{
    params[0] = dist * hauteur; //Largeur
    params[1] = hauteur; //Hauteur
    params[2] = nb_case_colonne*dist; //Nombre de cases par ligne (en largeur) (Nombre de colonnes)
    params[3] = nb_case_colonne; //Nombre de case par colonne (en hauteur) (Nombre de lignes)
    params[4] = hauteur/nb_case_colonne; //Le coté d'une case
}

Color Couleur(byte R, byte G, byte B)
{
    Color C = Color(R,G,B);
    return(C);
}

void dessineCase(int i, int j, int params_g[5], int etat)
{
    int size = params_g[4];
    if(etat==1)
        fillRect(i*size, j*size, size, size, BLACK);
    if(etat==2)
        fillRect(i*size, j*size, size, size, Couleur(100,100,100));
}

/* LE NIVEAU */

//Variables et paramètres
const int nb_para = 1;
int m_params_lvl[nb_para] = {20}; //[nombre de cases que l'utilisateur peut placer]

FMatrix<Case, 20, 10>  m_lvl1; //Matrice qui sert à définir l'état de chaque case (occupée ou non par un mur, ...)
                               //ATTENTION : Les parametres de lamatrice (de taille), doivent etre rentrés a la main, et recalculé a chaque chgmt
//Fonctions

void dessinDepart(){}

void whichCase(int &x, int &y, int params_g[5])
{
    x = x/params_g[4];
    y = y/params_g[4];
}

void initGrille(int params_g[5], FMatrix<Case, 20, 10>  &lvl1) //Structure l'espace de jeu
{
    // trace des ligne verticales
    for (int i=0 ; i<params_g[2] ; i++)
    {
        drawLine(i*params_g[4],0,i*params_g[4],params_g[1], BLACK, 1);
    }

    // trace des lignes horizontales
    for (int j=0 ; j<params_g[3] ; j++)
    {
        drawLine(0,j*params_g[4],params_g[0],j*params_g[4],BLACK,1);
    }

    //Dessin du lit
    Color beige = Couleur(250, 243, 182);
    Color bleu_couv = Couleur(22, 114, 156);
    Color bleu_drap = Couleur(188, 212, 226);
    fillRect(0, 0, params_g[4]*2, 3*params_g[4], bleu_drap);
    fillRect(0, params_g[4], params_g[4]*2, 2*params_g[4], bleu_couv);
    fillRect(params_g[4]/5, params_g[4]/4, 8*params_g[4]/5, params_g[4]/3, beige);

    //Phase de remplissage avec les obstacles predefinis
    for(int i=0; i<lvl1.nrow(); i++)
    {
        for(int j=0; j<lvl1.ncol(); j++)
        {
            int etat = lvl1(i,j).get_etat()==1;
            if(etat)
                dessineCase(i, j, params_g, etat);
        }
    }
}

void choixObstacles(int params_lvl[nb_para], int params_g[5], FMatrix<Case, 20, 10>  &lvl1)
{
    int x=0;
    int y=0;
    //Phase ou l'utilisateur choisi
    for(int i=0; i<params_lvl[0]; i++)
    {
         getMouse(x,y);
         whichCase(x, y, params_g);
         lvl1(x,y).set_etat(2);
         dessineCase(x, y, params_g, 2);
    }
}


int main()
{
    initParamsG(500, 10, 2, m_params_g);
    openWindow(m_params_g[0], m_params_g[1]);
    initGrille(m_params_g, m_lvl1);
    choixObstacles(m_params_lvl, m_params_g, m_lvl1);
    endGraphics();
	return 0;
}
